from .hive import registerHive
