# my_package/module2.py
def func2():
    return "Hello from module2!"
