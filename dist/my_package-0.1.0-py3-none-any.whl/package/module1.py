# my_package/module1.py
def func1():
    return "Hello from module1!"
