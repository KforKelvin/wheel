def hello():
    return "Hello, world!"